package com.example.yourstory.ui

import UserPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.yourstory.ui.Home.HomeViewModel
import com.example.yourstory.ui.login.LoginViewModel
import com.example.yourstory.ui.register.RegisterViewModel

class ViewModelFactory(private val pref: UserPreferences, private val dataStore: DataStore<Preferences>) : ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HomeViewModel::class.java)) {
            return HomeViewModel(pref, dataStore) as T
        }else if(modelClass.isAssignableFrom(RegisterViewModel::class.java)){
            return RegisterViewModel(pref,dataStore) as T
        }else if(modelClass.isAssignableFrom(LoginViewModel::class.java)){
            return LoginViewModel(pref,dataStore) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}