package com.example.yourstory.network.remote.retrofit

import com.example.yourstory.network.remote.responses.LoginResponse
import com.example.yourstory.network.remote.responses.RegisterResponse
import com.example.yourstory.network.remote.responses.StoriesResponse
import com.example.yourstory.network.remote.responses.StoryResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("stories")
    fun getStories(): Call<StoriesResponse>

    @GET("/stories/{id}")
    fun getStory(
        @Path("id") id:String
    ): Call<StoryResponse>

    @FormUrlEncoded
    @POST("register")
    fun register(
        @Field("name") name:String,
        @Field("email") email:String,
        @Field("password") password:String
    ): Call<RegisterResponse>

    @FormUrlEncoded
    @POST("login")
    fun login(
        @Field("email") email:String,
        @Field("password") password:String
    ): Call<LoginResponse>

    @Multipart
    @POST("stories")
    fun addStory(
        @Part file: MultipartBody.Part,
        @Part("description") description: RequestBody
    ): Call<RegisterResponse>
}